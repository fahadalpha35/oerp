Laravel Breeze
skydash admin template
Auth Guard
Group Middleware
error message alert bootstrap
Laravel Validation (Form Validation)
Intervention
